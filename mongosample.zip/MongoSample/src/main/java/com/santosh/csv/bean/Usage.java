package com.santosh.csv.bean;

public class Usage {
	private String PMN;
	private double ChargedVolumeMB;
	private double Calls;
	private double ChargedMinitues;
	private double Untis;
	private String CallDate;
	private String Country;

	public String getPMN() {
		return PMN;
	}

	public void setPMN(String pMN) {
		PMN = pMN;
	}

	public double getChargedVolumeMB() {
		return ChargedVolumeMB;
	}

	public void setChargedVolumeMB(double chargedVolumeMB) {
		ChargedVolumeMB = chargedVolumeMB;
	}

	public double getCalls() {
		return Calls;
	}

	public void setCalls(double calls) {
		Calls = calls;
	}

	public double getChargedMinitues() {
		return ChargedMinitues;
	}

	public void setChargedMinitues(double chargedMinitues) {
		ChargedMinitues = chargedMinitues;
	}

	public double getUntis() {
		return Untis;
	}

	public void setUntis(double untis) {
		Untis = untis;
	}

	public String getCallDate() {
		return CallDate;
	}

	public void setCallDate(String callDate) {
		CallDate = callDate;
	}

	public String getCountry() {
		return Country;
	}

	public void setCountry(String country) {
		Country = country;
	}

	@Override
	public String toString() {
		return "{'PMN':'" + PMN + "','ChargedVolumeMB':" + ChargedVolumeMB + ",'Calls':" + Calls + ",'ChargedMinitues':"
				+ ChargedMinitues + ",'Units':" + Untis + ",'CallDate':'" + CallDate + "','Country':'" + Country + "'}";

	}

}
