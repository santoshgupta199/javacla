package com.santosh.csv.bean;

public class CsvBean {
	private String Process_Date;
	private String PMN;
	private String Call_Type;
	private double Calls;
	private double ChargedMinutes;
	private double ChargedVolumeMB;

	public CsvBean(String process_Date, String pMN, String call_Type, double calls, double chargedMinutes,
			double chargedVolumeMB) {
		super();
		Process_Date = process_Date;
		PMN = pMN;
		Call_Type = call_Type;
		Calls = calls;
		ChargedMinutes = chargedMinutes;
		ChargedVolumeMB = chargedVolumeMB;
	}

	public String getProcess_Date() {
		return Process_Date;
	}

	public void setProcess_Date(String process_Date) {
		Process_Date = process_Date;
	}

	public String getPMN() {
		return PMN;
	}

	public void setPMN(String pMN) {
		PMN = pMN;
	}

	public String getCall_Type() {
		return Call_Type;
	}

	public void setCall_Type(String call_Type) {
		Call_Type = call_Type;
	}

	public double getCalls() {
		return Calls;
	}

	public void setCalls(double calls) {
		Calls = calls;
	}

	public double getChargedMinutes() {
		return ChargedMinutes;
	}

	public void setChargedMinutes(double chargedMinutes) {
		ChargedMinutes = chargedMinutes;
	}

	public double getChargedVolumeMB() {
		return ChargedVolumeMB;
	}

	public void setChargedVolumeMB(double chargedVolumeMB) {
		ChargedVolumeMB = chargedVolumeMB;
	}

	@Override
	public String toString() {
		return "CsvBean [Process_Date=" + Process_Date + ", PMN=" + PMN + ", Call_Type=" + Call_Type + ", Calls="
				+ Calls + ", ChargedMinutes=" + ChargedMinutes + ", ChargedVolumeMB=" + ChargedVolumeMB + "]";
	}

}
