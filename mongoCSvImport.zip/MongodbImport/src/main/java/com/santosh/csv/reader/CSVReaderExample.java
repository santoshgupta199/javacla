package com.santosh.csv.reader;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.opencsv.CSVReader;
import com.santosh.csv.bean.CsvBean;
import com.santosh.csv.bean.Usage;

import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;

public class CSVReaderExample {

	public static void main(String[] args) {

		String csvFile = "usage.csv";
		CSVReaderExample csvReaderExample = new CSVReaderExample();
		List<CsvBean> csvRecords = csvReaderExample.readFromCsv(csvFile);
		List<Usage> mongoRecords = csvReaderExample.compareListAndCreateUsageObjects(csvRecords);
		System.out.println(mongoRecords);
		System.out.println(mongoRecords.size());
		csvReaderExample.insertIntoMongo(mongoRecords);
	}

	public List<Usage> compareListAndCreateUsageObjects(List<CsvBean> csvBeansList) {
		List<Usage> usagesList = new ArrayList<Usage>();
		HashSet<String> pmnSet = new HashSet<String>();
		csvBeansList.forEach(list -> {
			pmnSet.add(list.getPMN());
		});
		pmnSet.forEach(country -> {
			Usage usage = new Usage();
			csvBeansList.forEach(list -> {

				if (list.getPMN().equals(country)) {
					usage.setCountry(list.getPMN().substring(0, 3));
					usage.setPMN(list.getPMN());
					usage.setCallDate(list.getProcess_Date());
					if (list.getCall_Type().equals("GPRS")) {

						usage.setChargedVolumeMB(list.getChargedVolumeMB());
					}
					if (list.getCall_Type().equals("MOC")) {
						usage.setChargedMinitues(list.getChargedMinutes());
					}
					if (list.getCall_Type().equals("MTC")) {
						usage.setCalls(list.getCalls());
					}

				}

			});
			double units = usage.getChargedVolumeMB() + usage.getChargedMinitues() + usage.getCalls();
			usage.setUntis(units);
			System.out.println(usage);
			usagesList.add(usage);

			// copyOfcsvBeansList.remove(list);
		});
		return usagesList;

	}

	public List<CsvBean> readFromCsv(String csvFile) {

		List<CsvBean> csvBeans = new ArrayList<CsvBean>();
		CsvBean csvBean;
		CSVReader reader = null;
		try {
			reader = new CSVReader(new FileReader(csvFile));

			List<String[]> list = reader.readAll();
			for (int i = 1; i < list.size(); i++) {
				String[] line = list.get(i);
				csvBean = new CsvBean(line[0], line[1], line[2], Double.parseDouble(line[3]),
						Double.parseDouble(line[4]), Double.parseDouble(line[5]));
				csvBeans.add(csvBean);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return csvBeans;

	}

	public void insertIntoMongo(List<Usage> mongoRecords) {
		int port_no = 27017;
		String auth_user = "reportsUser";
		String auth_pwd = "12345678";
		String host_name = "localhost";
		String db_name = "sai";
		String db_col_name = "Usage";
		String encoded_pwd = "";

		/*
		 * Imp. Note - 1. Developers will need to encode the 'auth_user' or the
		 * 'auth_pwd' string if it contains the <code>:</code> or the <code>@</code>
		 * symbol. If not, the code will throw the
		 * <code>java.lang.IllegalArgumentException</code>. 2. If the 'auth_user' or the
		 * 'auth_pwd' string does not contain the <code>:</code> or the <code>@</code>
		 * symbol, we can skip the encoding step.
		 */
		try {
			encoded_pwd = URLEncoder.encode(auth_pwd, "UTF-8");
		} catch (UnsupportedEncodingException ex) {
			System.out.println(ex);
		}

		// Mongodb connection string.
		String client_url = "mongodb://" + auth_user + ":" + encoded_pwd + "@" + host_name + ":" + port_no + "/"
				+ db_name;
		MongoClientURI uri = new MongoClientURI(client_url);

		MongoClient mongo = new MongoClient(uri);

//		DB db = mongo.getDB(DB_NAME);
//		boolean auth = db.authenticate("rcc", "password".toCharArray());
		MongoOperations mongoOps = new MongoTemplate(mongo, db_name);
		// DBCollection table = db.getCollection("user");
		List<String> records = new ArrayList<String>();
		mongoRecords.forEach(list -> records.add(list.toString()));
		mongoOps.insert(records, db_col_name);
	}
}